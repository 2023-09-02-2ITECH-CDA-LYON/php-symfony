<?php

namespace App\Controller;

use App\Entity\Hotel;
use App\Form\HotelType;
use App\Repository\HotelRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HotelController extends AbstractController
{
    private HotelRepository $hotelRepository;
    private EntityManagerInterface $em;

    public function __construct(HotelRepository $hotelRepository, EntityManagerInterface $em) {
        $this->hotelRepository = $hotelRepository;
        $this->em = $em;
    }
    #[Route('/hotel', name: 'app_hotel')]
    public function index(): Response
    {
        return $this->render('hotel/index.html.twig', [
            'hotels' => $this->hotelRepository->findAll()
        ]);
    }

    #[Route('/hotel/edit/{id}', name: 'app_hotel_edit')]
    public function edit(Hotel $hotel, Request $request) : Response {
        $form = $this->createForm(HotelType::class, $hotel);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            $this->em->persist($hotel);
            $this->em->flush();
            return $this->redirectToRoute('app_hotel');
        } else {
            return $this->render('hotel/edit.html.twig', [
                'form' => $form
            ]);
        }
    }

    #[Route('/hotel/delete/{id}', name: 'app_hotel_delete')]
    public function delete(Hotel $hotel, Request $request) : Response {
        if ($this->isCsrfTokenValid($hotel->getId(), $request->get('_token'))) {
            $this->em->remove($hotel);
            $this->em->flush();
        }
        return $this->redirectToRoute('app_hotel');
    }

    #[Route('/hotel/add', name: 'app_hotel_add')]
    public function add(Request $request) : Response {
        $hotel = new Hotel();
        $form = $this->createForm(HotelType::class, $hotel);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()) {
            $this->em->persist($hotel);
            $this->em->flush();
            return $this->redirectToRoute('app_hotel');
        }
        return $this->render('hotel/add.html.twig', [
            'form' => $form
        ]);
    }
}
