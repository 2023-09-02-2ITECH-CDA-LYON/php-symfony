<?php

namespace App\DataFixtures;

use App\Entity\Hotel;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
;

class HotelFixtures extends Fixture
{
    // php bin/console doctrine:fixtures:load
    public function load(ObjectManager $manager): void
    {
        $cities = [
            'Paris', 'Lyon', 'Marseille'
        ];
        for($i = 0; $i < 10; $i++) {
            $hotel = new Hotel();
            $hotel
                ->setCity(array_rand($cities))
                ->setDescription('Description '.$i)
                ->setName('Name '.$i);
            $manager->persist($hotel);
        }
        $manager->flush();
    }
}
